@echo off
:: 记录系统原始代码页（通常是 936），用于解决 PowerShell 65001 中文重影 Bug
for /f "tokens=2 delims=:" %%a in ('chcp') do set "ORIG_CP=%%a"
set "ORIG_CP=%ORIG_CP: =%"
chcp 65001 >nul
title Windows C盘终极全能清理脚本

:: ==========================================
:: 0. 检查并获取管理员权限 (自动提权)
:: ==========================================
>nul 2>&1 "%SYSTEMROOT%\system32\cacls.exe" "%SYSTEMROOT%\system32\config\system"
if '%errorlevel%' NEQ '0' (
    echo =====================================================
    echo    正在请求管理员权限，请在弹出的窗口中点击“是”...
    echo =====================================================
    echo Set UAC = CreateObject^("Shell.Application"^) > "%temp%\getadmin.vbs"
    echo UAC.ShellExecute "cmd.exe", "/c ""%~s0""", "", "runas", 1 >> "%temp%\getadmin.vbs"
    "%temp%\getadmin.vbs"
    del "%temp%\getadmin.vbs"
    exit /B
)

:: ==========================================
:: 第一阶段：自动静默清理常规垃圾 (极速模式)
:: ==========================================
echo =========================================
echo   [阶段一] 正在极速清理系统常规垃圾文件...
echo =========================================
echo.

echo [1/6] 正在清理系统临时文件夹...
del /f /s /q "%systemroot%\Temp\*.*" 2>nul
for /d %%p in ("%systemroot%\Temp\*.*") do rmdir "%%p" /s /q 2>nul

echo [2/6] 正在清理用户临时文件夹...
del /f /s /q "%temp%\*.*" 2>nul
for /d %%p in ("%temp%\*.*") do rmdir "%%p" /s /q 2>nul

echo [3/6] 正在清理系统预读取文件 (Prefetch)...
del /f /s /q "%systemroot%\Prefetch\*.*" 2>nul

echo [4/6] 正在清理 Windows 错误报告日志...
del /f /s /q "%ProgramData%\Microsoft\Windows\WER\ReportArchive\*.*" 2>nul
del /f /s /q "%ProgramData%\Microsoft\Windows\WER\ReportQueue\*.*" 2>nul

echo [5/6] 正在清理系统常规日志文件...
del /f /s /q "%systemroot%\*.log" 2>nul
del /f /s /q "%systemroot%\System32\LogFiles\*.*" 2>nul

echo [6/6] 正在清理图标和字体缓存...
del /f /s /q "%localappdata%\IconCache.db" 2>nul

echo.
echo 常规垃圾清理完毕！即将进入第二阶段深度扫描...
timeout /t 2 >nul

:: ==========================================
:: 第二阶段：极简安全调用 PowerShell (彻底杜绝解析Bug)
:: ==========================================
set "SCRIPT_PATH=%~f0"
:: 在调用 PowerShell 前恢复原始代码页，完美避开 Win10 的 65001 中文重影 Bug
chcp %ORIG_CP% >nul
powershell.exe -ExecutionPolicy Bypass -NoProfile -Command "$lines = Get-Content -LiteralPath $env:SCRIPT_PATH -Encoding UTF8; $idx = [Array]::IndexOf($lines, '#---' + 'PS_START---#'); if ($idx -ge 0) { $code = $lines[($idx+1)..($lines.Count-1)] -join \"`n\"; Invoke-Command -ScriptBlock ([scriptblock]::Create($code)) }"

exit /B

#---PS_START---#
# ==========================================
# 3. 以下为纯 PowerShell 交互核心代码
# ==========================================
try {
    Clear-Host
    Write-Host "=====================================================" -ForegroundColor Cyan
    Write-Host "        [阶段二] C盘深度扫描与大文件交互清理" -ForegroundColor Cyan
    Write-Host "=====================================================" -ForegroundColor Cyan
    Write-Host "正在扫描 C 盘潜在的大型可清理项，请稍候... " -ForegroundColor Yellow
    Write-Host ""

    # 辅助函数：获取文件夹大小
    function Get-FolderSize ($path) {
        if (Test-Path $path) {
            # 增加 -File 参数：仅计算文件，防止因遇到无 Length 属性的纯文件夹而抛出异常报错
            $size = (Get-ChildItem -Path $path -Recurse -Force -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
            if ($size -gt 0) { return [math]::Round($size / 1MB, 2) } else { return 0 }
        }
        return 0
    }

    # 1. 检查休眠文件 (hiberfil.sys)
    $hiberPath = "C:\hiberfil.sys"
    if (Test-Path $hiberPath) {
        $hiberSize = (Get-Item $hiberPath -Force).Length / 1GB
        $hiberSize = [math]::Round($hiberSize, 2)
        Write-Host " [发现] 休眠文件 (hiberfil.sys) 占用: $hiberSize GB " -ForegroundColor Magenta
        Write-Host "   说明：如果你平时不使用电脑的休眠功能（注意不是睡眠），可以关闭它来释放这部分空间。 "
        $ans = Read-Host " -> 是否关闭休眠并删除此文件？(Y/N)"
        if ($ans -match "^[Yy]$") {
            powercfg -h off
            Write-Host "   [完成] 已关闭休眠功能并删除休眠文件。 " -ForegroundColor Green
        } else {
            Write-Host "   [跳过] 保留休眠功能。 " -ForegroundColor DarkGray
        }
        Write-Host ""
    }

    # 2. 检查以前的 Windows 安装 (Windows.old)
    $winOldPath = "C:\Windows.old"
    if (Test-Path $winOldPath) {
        Write-Host " [发现] 正在计算 Windows.old 文件夹大小，请稍候... " -ForegroundColor Yellow
        $winOldSize = Get-FolderSize $winOldPath
        Write-Host " [发现] 旧版 Windows 备份 (Windows.old) 占用: $winOldSize MB " -ForegroundColor Magenta
        Write-Host "   说明：这是系统升级前的备份。如果当前系统运行正常且不需要退回老版本，可以删除。 "
        $ans = Read-Host " -> 是否删除 Windows.old 文件夹？(Y/N)"
        if ($ans -match "^[Yy]$") {
            Write-Host "   正在删除，这可能需要几分钟时间... " -ForegroundColor Yellow
            cmd.exe /c "takeown /F C:\Windows.old\* /R /A /D Y" 2>&1 | Out-Null
            cmd.exe /c "cacls C:\Windows.old\*.* /T /grant administrators:F" 2>&1 | Out-Null
            cmd.exe /c "rmdir /S /Q C:\Windows.old" 2>&1 | Out-Null
            Write-Host "   [完成] 已尝试删除 Windows.old。 " -ForegroundColor Green
        } else {
            Write-Host "   [跳过] 保留 Windows.old。 " -ForegroundColor DarkGray
        }
        Write-Host ""
    }

    # 3. 检查系统软件分发下载缓存 (Windows Update 残留)
    $softDistPath = "C:\Windows\SoftwareDistribution\Download"
    if (Test-Path $softDistPath) {
        $softDistSize = Get-FolderSize $softDistPath
        if ($softDistSize -gt 100) {
            Write-Host " [发现] Windows 更新下载缓存 占用: $softDistSize MB " -ForegroundColor Magenta
            Write-Host "   说明：系统更新完成后留下的安装包，通常可以安全删除。 "
            $ans = Read-Host " -> 是否清空更新缓存？(Y/N)"
            if ($ans -match "^[Yy]$") {
                Remove-Item -Path "$softDistPath\*" -Recurse -Force -ErrorAction SilentlyContinue
                Write-Host "   [完成] 已清理 Windows 更新缓存。 " -ForegroundColor Green
            } else {
                Write-Host "   [跳过] 保留更新缓存。 " -ForegroundColor DarkGray
            }
            Write-Host ""
        }
    }

    # 4. 检查 Windows 传递优化缓存 (Delivery Optimization)
    $doCachePath = "C:\Windows\ServiceProfiles\NetworkService\AppData\Local\Microsoft\Windows\DeliveryOptimization\Cache"
    if (Test-Path $doCachePath) {
        $doSize = Get-FolderSize $doCachePath
        if ($doSize -gt 200) {
            Write-Host " [发现] Windows 传递优化缓存 占用: $doSize MB " -ForegroundColor Magenta
            Write-Host "   说明：系统为了加速网络共享更新而下载的缓存文件，完全可以安全删除。 "
            $ans = Read-Host " -> 是否清空传递优化缓存？(Y/N)"
            if ($ans -match "^[Yy]$") {
                Remove-Item -Path "$doCachePath\*" -Recurse -Force -ErrorAction SilentlyContinue
                Write-Host "   [完成] 已清理传递优化缓存。 " -ForegroundColor Green
            } else {
                Write-Host "   [跳过] 保留传递优化缓存。 " -ForegroundColor DarkGray
            }
            Write-Host ""
        }
    }

    # 5. 检查系统蓝屏崩溃转储文件 (Memory.dmp)
    $dumpPath = "C:\Windows\Memory.dmp"
    if (Test-Path $dumpPath) {
        $dumpSize = [math]::Round((Get-Item $dumpPath).Length / 1MB, 2)
        if ($dumpSize -gt 200) {
            Write-Host " [发现] 系统崩溃转储文件 (Memory.dmp) 占用: $dumpSize MB " -ForegroundColor Magenta
            Write-Host "   说明：电脑遇到蓝屏死机时生成的错误分析报告。如果不打算深究蓝屏原因，建议直接删除。 "
            $ans = Read-Host " -> 是否删除系统崩溃转储文件？(Y/N)"
            if ($ans -match "^[Yy]$") {
                Remove-Item -Path $dumpPath -Force -ErrorAction SilentlyContinue
                Write-Host "   [完成] 已清理崩溃转储文件。 " -ForegroundColor Green
            } else {
                Write-Host "   [跳过] 保留崩溃转储文件。 " -ForegroundColor DarkGray
            }
            Write-Host ""
        }
    }

    # 6. 清理回收站提示
    Write-Host " [发现] 正在检查系统回收站... " -ForegroundColor Yellow
    $ansRecycle = Read-Host " -> 是否一键清空系统回收站？(Y/N)"
    if ($ansRecycle -match "^[Yy]$") {
        Clear-RecycleBin -Force -ErrorAction SilentlyContinue
        Write-Host "   [完成] 已清空回收站。 " -ForegroundColor Green
    } else {
        Write-Host "   [跳过] 保留回收站文件。 " -ForegroundColor DarkGray
    }
    Write-Host ""

    # 7. 检查微信电脑版默认缓存路径 (只提示，不自动删)
    $wechatPath = "$env:USERPROFILE\Documents\WeChat Files"
    if (Test-Path $wechatPath) {
        Write-Host " [发现] 正在计算微信文件缓存大小，请稍候... " -ForegroundColor Yellow
        $wechatSize = Get-FolderSize $wechatPath
        if ($wechatSize -gt 500) { 
            $wechatSizeGB = [math]::Round($wechatSize / 1024, 2)
            Write-Host " [警告] 你的微信文件默认保存在 C 盘，占用: $wechatSizeGB GB " -ForegroundColor Red
            Write-Host "   强烈建议：打开微信电脑版 -> 左下角设置 -> 文件管理 -> 更改 -> 选择 D 盘或 E 盘。 " -ForegroundColor Cyan
            Write-Host "   本脚本不会自动删除微信文件以防止数据丢失，请手动在微信软件内迁移。 " -ForegroundColor Cyan
            Read-Host "   (按回车键继续扫描...)"
            Write-Host ""
        }
    }

    # 8. 检查 QQ 电脑版默认缓存路径 (只提示，不自动删)
    $qqPath = "$env:USERPROFILE\Documents\Tencent Files"
    if (Test-Path $qqPath) {
        $qqSize = Get-FolderSize $qqPath
        if ($qqSize -gt 500) {
            $qqSizeGB = [math]::Round($qqSize / 1024, 2)
            Write-Host " [警告] 你的QQ文件默认保存在 C 盘，占用: $qqSizeGB GB " -ForegroundColor Red
            Write-Host "   强烈建议：打开QQ -> 设置 -> 存储管理 -> 更改文件存储位置到其他盘。 " -ForegroundColor Cyan
            Read-Host "   (按回车键继续扫描...)"
            Write-Host ""
        }
    }

    # 9. 检查下载文件夹 (只做体积警告，不自动删)
    $dlPath = "$env:USERPROFILE\Downloads"
    if (Test-Path $dlPath) {
        Write-Host " [发现] 正在计算下载文件夹大小，请稍候... " -ForegroundColor Yellow
        $dlSize = Get-FolderSize $dlPath
        if ($dlSize -gt 1000) {
            $dlSizeGB = [math]::Round($dlSize / 1024, 2)
            Write-Host " [警告] 你的下载文件夹占用: $dlSizeGB GB " -ForegroundColor Red
            Write-Host "   强烈建议：许多人习惯把安装包下完就丢在这里。请抽空手动前往清理无用文件。 " -ForegroundColor Cyan
            Read-Host "   (按回车键继续...)"
            Write-Host ""
        }
    }

    Write-Host "=====================================================" -ForegroundColor Cyan
    Write-Host "清理与扫描流程全部结束！你的 C 盘现在处于最佳状态。" -ForegroundColor Green
    Write-Host "=====================================================" -ForegroundColor Cyan

} catch {
    # 彻底内置的异常捕获机制，无论如何绝不闪退
    Write-Host ""
    Write-Host "执行过程中发生未知报错，拦截信息如下：" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Yellow
} finally {
    # 彻底锁死窗口底线：即使代码出错，也会停在这里等你按回车
    Write-Host ""
    Read-Host " [执行完毕] 请按回车键 (Enter) 关闭本窗口..."
}